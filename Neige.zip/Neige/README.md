# ODK Neige - Sujet de stage 2020 (CESBIO)
 App. de collecte de données codée en Java (Android Studio)
https://drive.google.com/file/d/1P8oHH_KjfgRzLDswx3gbZRMPI7X62r8j/view?usp=sharing (la prévisualisation du fichier sur Google Drive ne marche pas très bien, vaut mieux télécharger le doc)
